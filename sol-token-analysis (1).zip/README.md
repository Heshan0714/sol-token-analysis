# SCANR — Solana Token Analysis Platform

Combines on-chain SPL mint data, holder concentration, and live market data
(DexScreener, optional Birdeye) into a single risk-scored token report.

## Structure

```
sol-token-analysis/
├── backend/     Express API — /api/analyze/:mint
└── frontend/    React + Vite scanner UI
```

## Backend setup

```bash
cd backend
cp .env.example .env    # fill in SOLANA_RPC_URL (and BIRDEYE_API_KEY if you have one)
npm install
npm start                # or: node index.js
```

The public `api.mainnet-beta.solana.com` RPC works for testing but rate-limits
quickly. For real use, get a free RPC endpoint from Helius (helius.dev) or
QuickNode and put it in `.env`.

## Frontend setup

```bash
cd frontend
npm install
npm run dev
```

By default the frontend calls `http://localhost:4000`. To point at a deployed
backend, create `frontend/.env` with:

```
VITE_API_BASE=https://your-backend-url.com
```

## What it checks

- **On-chain (Solana RPC):** mint authority, freeze authority, top holder
  accounts and their % of total supply
- **Market (DexScreener + optional Birdeye):** price, liquidity, 24h volume,
  market cap, pair age
- **LP lock/burn (Raydium pools, best-effort):** whether the pool's LP
  tokens are burned, locked in a known locker program, or freely held —
  `backend/lpLock.js`. Non-Raydium pools report `status: "unknown"`.
- **Risk score (0–100):** weighted combination of the above, with a
  human-readable flag for each signal (`backend/riskEngine.js`)

## Additional features

- **Price history chart** — `GET /api/price-history/:mint`. Needs
  `BIRDEYE_API_KEY` in `.env`; without it the frontend shows a clear
  "unavailable" state instead of erroring.
- **Wallet activity timeline** — `GET /api/wallet/:address/activity`.
  Pulls recent signatures + program IDs touched for any Solana address, no
  API key needed (uses your configured `SOLANA_RPC_URL`).
- **Watchlist** — `GET/POST /api/watchlist`, `DELETE /api/watchlist/:mint`.
  Persisted in `backend/data.sqlite` (SQLite via better-sqlite3, created
  automatically on first run). Save a scanned token, then click it in the
  watchlist panel to re-scan instantly.

## Deploying

**Backend → Railway** (needs a persistent process + disk for `data.sqlite`,
which Vercel's serverless functions can't provide):

1. Push this repo to GitHub.
2. In Railway: New Project → Deploy from GitHub repo.
3. In the service settings, set **Root Directory** to `backend`.
4. Add environment variables: `SOLANA_RPC_URL` (and `BIRDEYE_API_KEY` if you
   have one). Railway sets `PORT` automatically — the app already reads it.
5. Deploy. Railway auto-detects Node via `package.json`/`railway.json` and
   runs `npm start`.
6. Copy the generated public URL (Settings → Networking → Generate Domain).
7. **Note:** on Railway's default filesystem, `data.sqlite` persists across
   restarts but is wiped on a fresh deploy/rebuild unless you attach a
   [volume](https://docs.railway.app/reference/volumes) mounted at
   `backend/`. Fine for testing; add a volume once the watchlist matters.

**Frontend → Vercel:**

1. Import the same repo in Vercel.
2. Set **Root Directory** to `frontend` (this repo is a monorepo — missing
   this step is the most common cause of a blank deployed page).
3. Add environment variable `VITE_API_BASE` = your Railway URL from above.
4. Build command `npm run build`, output directory `dist` (Vercel's Vite
   preset sets these automatically).
5. Deploy.

If the deployed frontend loads but shows no data, open the browser console —
it's almost always `VITE_API_BASE` pointing at the wrong URL or the backend
CORS/env vars not set.

## Extending it

- Swap/add data sources in `backend/marketData.js`
- Tune scoring weights in `backend/riskEngine.js`
- `lpLock.js`'s `KNOWN_LOCKER_PROGRAMS` set is a starting point — add real
  program IDs for the lockers common in your target market (e.g.
  Streamflow) as you identify them
- `data.sqlite` is a single file — fine for personal/local use; swap
  `db.js` for Postgres if this ever needs multiple concurrent users
